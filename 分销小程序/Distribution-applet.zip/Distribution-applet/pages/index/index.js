//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
   
  },
  navtoTxHistory(e){
    wx.navigateTo({
      url: '/pages/nome1/nome1',
    });
  },
  navtoNome2(e){
    wx.navigateTo({
      url: '/pages/nome2/nome2',
    });
  },
  //下方容器的四个跳转JS
  navtoExtensionCard(e){
    wx.navigateTo({
      url: '/pages/extensionCard/extensionCard'
    });
  },
  navtoNome3(e){
    wx.navigateTo({
      url: '/pages/nome3/nome3'
    });
  },
  navtoCommission(e){
    wx.navigateTo({
      url: '/pages/commission/commission'
    });
  },
  navtoExtensionRank(e){
    wx.navigateTo({
      url: '/pages/extensionRank/extensionRank'
    });
  }
})
